<?php

// PDF Conversion service provided by "HTML 2 PDF Rocket" https://www.html2pdfrocket.com
// First we create the html file, then make an API call to HTML2PDF Rocket and his service converts
// the html to a PDF file. 200 conversions per month for free, more than that for a monthly charge.

//run the script that creates the html file
include "UPDATER-html.php";

//set PDF file parameters, including URL to the footer. The footer produces the "Created On" date and page numbers.
$postdata = http_build_query(
    array(
        'apikey' => '2f4c7a19-b7ca-4c94-bc57-c67a4a826bea',
        'value' => 'https://www.calligraphydallas.com/updater/AU.working.html',    //URL to the html file we are going to convert
        'MarginBottom' => '13',
        'MarginTop' => '12',
		'MarginLeft' => '10',
		'MarginRight' => '10',
		'UseLandscape' => 'false',
        'FooterURL' => 'https://www.calligraphydallas.com/updater/UPDATER-pdf.footer.php'   //URL to the pdf footer script
    )
);
 
$opts = array('http' =>
    array(
        'method'  => 'POST',
        'header'  => 'Content-type: application/x-www-form-urlencoded',
        'content' => $postdata
    )
);

//make the API call to the "HTML 2 PDF Rocket" conversion service
$context  = stream_context_create($opts);
$result = file_get_contents('http://api.html2pdfrocket.com/pdf', false, $context);

//save the PDF to disk
file_put_contents($filename, $result);

//Download the PDF to the user's download folder
header('Content-Type: application/download');
header("Content-Disposition: attachment; filename=".$filename);
header("Content-Length: " . filesize($filename));

$fp = fopen($filename, "r");
fpassthru($fp);

//close and delete the leftovers
$leftovers = 'AU*';
array_map( "fclose", glob( $leftovers ));
array_map( "unlink", glob( $leftovers ));	
?>